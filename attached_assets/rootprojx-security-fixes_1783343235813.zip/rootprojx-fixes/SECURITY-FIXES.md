# Root ProjX — Critical Security Fixes (July 6, 2026)

Three files changed. Drop each into the same path in your Replit project,
then complete the **manual actions** below — the code fixes are not complete
without them.

## Changed files

| File | Path in project |
|---|---|
| `webhooks.ts` | `artifacts/api-server/src/routes/webhooks.ts` |
| `firebase-rest.ts` | `artifacts/api-server/src/lib/firebase-rest.ts` |
| `.replit` | `.replit` (project root) |

## What was fixed

### 1. Stripe webhook now fails closed (webhooks.ts)
Before: if `STRIPE_WEBHOOK_SECRET` was unset, the webhook silently accepted
**unverified** events — anyone could POST fake `payment_intent.succeeded`
payloads and create donation records or inflate an org's `totalRaised`.
Now: no secret → webhook rejects with a loud error log. Unverified mode only
works in local dev with an explicit `ALLOW_UNVERIFIED_STRIPE_WEBHOOKS=true`
opt-in, and never in a Replit deployment.

### 2. Webhook is now idempotent (webhooks.ts)
Stripe retries webhook deliveries. Before, every retry created a duplicate
donation document and re-incremented `totalRaised`. Now the handler checks
whether a donation/order with the same `stripeRef` already exists and skips
if so.

### 3. Atomic counters (webhooks.ts + firebase-rest.ts)
`totalRaised` and `followerCount` were updated by reading the whole org doc
and writing it back — concurrent donations lost counts, and a stale write
could clobber simultaneous profile edits. New `fsIncrement()` helper uses
Firestore's server-side `increment` transform: concurrency-safe, touches
only the counter field.

### 4. Hardcoded server password removed (firebase-rest.ts)
`FIREBASE_SERVER_PASSWORD` had a hardcoded fallback (`RootSeed2024!`)
committed to git. Combined with the Firestore rule that grants full database
access to the `seeder@rootprojx.internal` account, this was a full-database
compromise for anyone with repo access. The fallback is removed; the server
now refuses privileged operations until the env var is set.

### 5. JWT_SECRET removed from .replit
The `.replit` file is tracked in git and contained a hardcoded `JWT_SECRET`.
It was unused by the codebase, so removal is safe.

## ⚠️ Manual actions required — do these today

1. **Rotate the server account password.** Firebase Console → Authentication
   → find `seeder@rootprojx.internal` → reset to a long random password.
   Assume the old one (`RootSeed2024!`) is public.
2. **Set the new password in Replit Secrets** as `FIREBASE_SERVER_PASSWORD`.
   The API server will now refuse privileged operations without it.
3. **Set `STRIPE_WEBHOOK_SECRET` in Replit Secrets.** Stripe Dashboard →
   Developers → Webhooks → your endpoint → "Signing secret" (`whsec_...`).
   Without it, donation recording stops working (by design, now).
4. **Verify with a test donation** (Stripe test mode): confirm the donation
   doc is created once, `totalRaised` increments correctly, and re-sending
   the same event from the Stripe dashboard does NOT double-count.
5. **Treat git history as compromised.** The old password and JWT_SECRET
   remain in previous commits. Rotation (steps 1–3) is what actually fixes
   this — scrubbing history is optional afterward.

## Next round (recommended, not yet done)

- Replace the email/password "server account" with the Firebase Admin SDK
  service account (`firebase-admin` is already a dependency) and remove the
  `isServer()` email-match rule from `firestore.rules`.
- Lock down `storage.rules` — currently any signed-in user can read/write
  ANY path in the bucket.
- Rate-limit `/donations/guest-payment-intent` (card-testing abuse vector);
  wire up the already-installed `express-rate-limit` package.
- Parse request bodies with the existing `@workspace/api-zod` schemas
  instead of `req.body as {...}` casts; add max donation amount.
- Add `helmet`, restrict CORS to your real domains.
- Add tests for the webhook (idempotency, fee math) + GitHub Actions CI.
