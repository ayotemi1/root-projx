const API_KEY = process.env.FIREBASE_API_KEY!;
const PROJECT_ID = process.env.FIREBASE_PROJECT_ID!;
const IDENTITY = "https://identitytoolkit.googleapis.com/v1/accounts";
const FIRESTORE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;

// Server-side token cache — used for server-initiated Firestore reads (no user token available)
// SECURITY: the server password must come from the environment. Never hardcode a
// fallback here — a committed password grants full database access to anyone
// who has ever read this repository.
const SERVER_EMAIL = process.env.FIREBASE_SERVER_EMAIL ?? "seeder@rootprojx.internal";
const SERVER_PASS = process.env.FIREBASE_SERVER_PASSWORD;
let _serverToken: string | null = null;
let _serverTokenExpiry = 0;

export async function getServerToken(): Promise<string> {
  if (!SERVER_PASS) {
    throw new Error(
      "FIREBASE_SERVER_PASSWORD is not set. Privileged Firestore operations are disabled until it is configured in Replit Secrets.",
    );
  }
  if (_serverToken && Date.now() < _serverTokenExpiry) return _serverToken;
  const res = await fetch(`${IDENTITY}:signInWithPassword?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: SERVER_EMAIL, password: SERVER_PASS, returnSecureToken: true }),
  });
  const data = await res.json() as Record<string, unknown>;
  if (!res.ok) throw new Error("Server token refresh failed");
  _serverToken = data.idToken as string;
  _serverTokenExpiry = Date.now() + 55 * 60 * 1000; // refresh 5 min before 1-hour expiry
  return _serverToken;
}

// ─── Firebase Auth REST ───────────────────────────────────────────────────────

export async function firebaseSignUp(email: string, password: string) {
  const res = await fetch(`${IDENTITY}:signUp?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });
  const data = await res.json() as Record<string, unknown>;
  if (!res.ok) {
    const code = ((data.error as Record<string, unknown>)?.message as string) ?? "SIGNUP_FAILED";
    throw Object.assign(new Error(code), { firebaseCode: code });
  }
  return { idToken: data.idToken as string, uid: data.localId as string };
}

export async function firebaseSignIn(email: string, password: string) {
  const res = await fetch(`${IDENTITY}:signInWithPassword?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });
  const data = await res.json() as Record<string, unknown>;
  if (!res.ok) {
    const code = ((data.error as Record<string, unknown>)?.message as string) ?? "SIGNIN_FAILED";
    throw Object.assign(new Error(code), { firebaseCode: code });
  }
  return { idToken: data.idToken as string, uid: data.localId as string };
}

export async function firebaseLookup(idToken: string): Promise<{ uid: string; email: string } | null> {
  const res = await fetch(`${IDENTITY}:lookup?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken }),
  });
  if (!res.ok) return null;
  const data = await res.json() as Record<string, unknown>;
  const users = data.users as Record<string, unknown>[] | undefined;
  const user = users?.[0];
  if (!user) return null;
  return { uid: user.localId as string, email: user.email as string };
}

export async function firebaseUpdateProfile(idToken: string, displayName: string) {
  await fetch(`${IDENTITY}:update?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken, displayName }),
  });
}

// ─── Firestore REST ───────────────────────────────────────────────────────────

type FsValue =
  | { stringValue: string }
  | { integerValue: string }
  | { doubleValue: number }
  | { booleanValue: boolean }
  | { nullValue: null }
  | { timestampValue: string }
  | { arrayValue: { values?: FsValue[] } }
  | { mapValue: { fields: Record<string, FsValue> } };

function toFsVal(v: unknown): FsValue {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === "string") return { stringValue: v };
  if (typeof v === "number") return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (typeof v === "boolean") return { booleanValue: v };
  if (v instanceof Date) return { timestampValue: v.toISOString() };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(toFsVal) } };
  if (typeof v === "object") {
    const fields: Record<string, FsValue> = {};
    for (const [k, fv] of Object.entries(v as Record<string, unknown>)) {
      fields[k] = toFsVal(fv);
    }
    return { mapValue: { fields } };
  }
  return { stringValue: String(v) };
}

function fromFsVal(v: FsValue): unknown {
  if ("stringValue" in v) return v.stringValue;
  if ("integerValue" in v) return Number(v.integerValue);
  if ("doubleValue" in v) return v.doubleValue;
  if ("booleanValue" in v) return v.booleanValue;
  if ("nullValue" in v) return null;
  if ("timestampValue" in v) return v.timestampValue;
  if ("arrayValue" in v) return (v.arrayValue.values ?? []).map(fromFsVal);
  if ("mapValue" in v) {
    const res: Record<string, unknown> = {};
    for (const [k, fv] of Object.entries(v.mapValue.fields)) res[k] = fromFsVal(fv);
    return res;
  }
  return null;
}

function fromFsDoc(fields: Record<string, FsValue>): Record<string, unknown> {
  const res: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(fields)) res[k] = fromFsVal(v);
  return res;
}

export async function fsGet(
  collection: string,
  docId: string,
  idToken?: string,
): Promise<Record<string, unknown> | null> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(`${FIRESTORE}/${collection}/${docId}`, { headers });
  if (res.status === 404) return null;
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore GET ${collection}/${docId} failed ${res.status}: ${text.slice(0, 200)}`);
  }
  const doc = await res.json() as { fields?: Record<string, FsValue> };
  return fromFsDoc(doc.fields ?? {});
}

export async function fsPatch(
  collection: string,
  docId: string,
  data: Record<string, unknown>,
  idToken?: string,
): Promise<void> {
  const fields: Record<string, FsValue> = {};
  for (const [k, v] of Object.entries(data)) fields[k] = toFsVal(v);

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;

  const res = await fetch(`${FIRESTORE}/${collection}/${docId}`, {
    method: "PATCH",
    headers,
    body: JSON.stringify({ fields }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore PATCH ${collection}/${docId} failed ${res.status}: ${text.slice(0, 200)}`);
  }
}

export async function fsQuery(
  collection: string,
  filters: Array<{ field: string; op: string; value: unknown }>,
  idToken?: string,
  opts?: { orderBy?: { field: string; dir?: "ASCENDING" | "DESCENDING" }; limit?: number },
): Promise<Array<Record<string, unknown>>> {
  const where =
    filters.length === 0
      ? undefined
      : filters.length === 1
        ? {
            fieldFilter: {
              field: { fieldPath: filters[0]!.field },
              op: filters[0]!.op,
              value: toFsVal(filters[0]!.value),
            },
          }
        : {
            compositeFilter: {
              op: "AND",
              filters: filters.map((f) => ({
                fieldFilter: {
                  field: { fieldPath: f.field },
                  op: f.op,
                  value: toFsVal(f.value),
                },
              })),
            },
          };

  const structuredQuery: Record<string, unknown> = {
    from: [{ collectionId: collection }],
    ...(where ? { where } : {}),
    ...(opts?.orderBy
      ? { orderBy: [{ field: { fieldPath: opts.orderBy.field }, direction: opts.orderBy.dir ?? "DESCENDING" }] }
      : {}),
    ...(opts?.limit ? { limit: opts.limit } : {}),
  };

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;

  const res = await fetch(
    `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents:runQuery`,
    { method: "POST", headers, body: JSON.stringify({ structuredQuery }) },
  );
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore query failed ${res.status}: ${text.slice(0, 200)}`);
  }
  const rows = await res.json() as Array<{ document?: { fields?: Record<string, FsValue>; name?: string } }>;
  return rows
    .filter((r) => r.document?.fields)
    .map((r) => ({
      _id: r.document!.name?.split("/").pop() ?? "",
      ...fromFsDoc(r.document!.fields!),
    }));
}

export async function fsList(
  collection: string,
  idToken?: string,
  pageSize = 100,
): Promise<Array<Record<string, unknown>>> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(`${FIRESTORE}/${collection}?pageSize=${pageSize}`, { headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore LIST ${collection} failed ${res.status}: ${text.slice(0, 200)}`);
  }
  const body = await res.json() as { documents?: Array<{ fields?: Record<string, FsValue>; name?: string }> };
  return (body.documents ?? []).map((d) => ({
    _id: d.name?.split("/").pop() ?? "",
    ...fromFsDoc(d.fields ?? {}),
  }));
}

export async function fsDelete(
  collection: string,
  docId: string,
  idToken?: string,
): Promise<void> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(`${FIRESTORE}/${collection}/${docId}`, { method: "DELETE", headers });
  if (!res.ok && res.status !== 404) {
    const text = await res.text();
    throw new Error(`Firestore DELETE ${collection}/${docId} failed ${res.status}: ${text.slice(0, 200)}`);
  }
}

// Atomically increment one or more numeric fields on a document using Firestore's
// server-side `increment` transform. Unlike read-modify-write (fsGet + fsPatch),
// this is safe under concurrency: two simultaneous donations both land correctly,
// and no other fields on the document are touched or overwritten.
export async function fsIncrement(
  collection: string,
  docId: string,
  increments: Record<string, number>,
  idToken?: string,
): Promise<void> {
  const docPath = `projects/${PROJECT_ID}/databases/(default)/documents/${collection}/${docId}`;
  const fieldTransforms = Object.entries(increments).map(([fieldPath, amount]) => ({
    fieldPath,
    increment: Number.isInteger(amount)
      ? { integerValue: String(amount) }
      : { doubleValue: amount },
  }));

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;

  const res = await fetch(
    `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents:commit`,
    {
      method: "POST",
      headers,
      body: JSON.stringify({
        writes: [
          {
            transform: { document: docPath, fieldTransforms },
            // Only apply to existing documents — never create a phantom org/user
            // doc as a side effect of an increment.
            currentDocument: { exists: true },
          },
        ],
      }),
    },
  );
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore INCREMENT ${collection}/${docId} failed ${res.status}: ${text.slice(0, 200)}`);
  }
}

export async function fsCreate(
  collection: string,
  data: Record<string, unknown>,
  idToken?: string,
): Promise<string> {
  const fields: Record<string, FsValue> = {};
  for (const [k, v] of Object.entries(data)) fields[k] = toFsVal(v);
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(`${FIRESTORE}/${collection}`, {
    method: "POST",
    headers,
    body: JSON.stringify({ fields }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore POST ${collection} failed ${res.status}: ${text.slice(0, 200)}`);
  }
  const doc = await res.json() as { name?: string };
  return doc.name?.split("/").pop() ?? "";
}
