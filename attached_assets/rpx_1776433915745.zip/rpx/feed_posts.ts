import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";

export const feedPostsTable = pgTable("feed_posts", {
  id: text("id").primaryKey(),
  orgId: text("org_id").notNull(),
  orgInitials: text("org_initials").notNull(),
  orgName: text("org_name").notNull(),
  tag: text("tag").notNull(), // Before | During | After | Need
  caption: text("caption").notNull(),
  timeAgo: text("time_ago").notNull(),
  likesCount: integer("likes_count").notNull().default(0),
  commentsCount: integer("comments_count").notNull().default(0),
  needType: text("need_type"), // volunteer | donate | skills
  emoji: text("emoji"),
  gradientFrom: text("gradient_from"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type FeedPost = typeof feedPostsTable.$inferSelect;
