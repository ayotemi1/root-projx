const colors = {
  light: {
    text: "#1A1A1A",
    tint: "#F5B800",

    background: "#FAF5EB",
    foreground: "#FFFFFF",

    card: "#FFFFFF",
    cardForeground: "#1A1A1A",

    primary: "#F5B800",
    primaryForeground: "#9A0000",

    secondary: "#F3F4F6",
    secondaryForeground: "#1A1A1A",

    muted: "#F3F4F6",
    mutedForeground: "#9CA3AF",

    accent: "#FFF3CC",
    accentForeground: "#9A0000",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#E5E7EB",
    input: "#F3F4F6",

    deepRed: "#CC0000",
    midRed: "#CC0000",
    gold: "#F5B800",
    goldLight: "#FFF3CC",
    whiteFaint: "#E5E7EB",
  },
  radius: 12,
};

export default colors;
