import { pgTable, text, timestamp, boolean, real, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const organisationsTable = pgTable("organisations", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  mission: text("mission").notNull(),
  location: text("location").notNull(),
  country: text("country").notNull(), // JM | GB
  causeCategory: text("cause_category").notNull(),
  goalAmount: real("goal_amount").notNull().default(0),
  raisedAmount: real("raised_amount").notNull().default(0),
  distributedAmount: real("distributed_amount").notNull().default(0),
  donorCount: integer("donor_count").notNull().default(0),
  followerCount: integer("follower_count").notNull().default(0),
  verified: boolean("verified").notNull().default(false),
  initials: text("initials").notNull(),
  lat: real("lat").notNull().default(0),
  lng: real("lng").notNull().default(0),
  needs: jsonb("needs").notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrganisationSchema = createInsertSchema(organisationsTable).omit({ createdAt: true });
export type InsertOrganisation = z.infer<typeof insertOrganisationSchema>;
export type Organisation = typeof organisationsTable.$inferSelect;
