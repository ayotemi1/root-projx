export interface Need {
  type: "Money" | "Skills" | "Time" | "Presence";
  description: string;
  urgency: "URGENT" | "OPEN" | "UPCOMING";
  icon: string;
}

export interface StoryFrame {
  id: string;
  emoji: string;
  text: string;
  subtext?: string;
  gradientFrom: string;
  gradientTo: string;
}

export interface FeedPost {
  id: string;
  orgId: string;
  orgInitials: string;
  orgName: string;
  tag: "Before" | "During" | "After" | "Need";
  caption: string;
  timeAgo: string;
  likesCount: number;
  commentsCount: number;
  needType?: "volunteer" | "donate" | "skills";
  visual: {
    type: "gradient" | "image";
    emoji?: string;
    gradientFrom?: string;
    gradientTo?: string;
    imageKey?: "community" | "uk";
  };
}

export interface Organisation {
  id: string;
  name: string;
  shortName: string;
  mission: string;
  location: string;
  country: "JM" | "GB";
  causeCategory: string;
  goalAmount: number;
  raisedAmount: number;
  distributedAmount: number;
  donorCount: number;
  followerCount: number;
  verified: boolean;
  initials: string;
  stories: StoryFrame[];
  needs: Need[];
  lat: number;
  lng: number;
}

export interface ImpactUpdate {
  id: string;
  orgId: string;
  orgInitials: string;
  orgName: string;
  title: string;
  body: string;
  tag: "Before" | "During" | "After" | "Need";
  date: string;
  timeAgo: string;
  needType?: "volunteer" | "donate" | "skills";
}

export interface EcosystemPost {
  id: string;
  orgId: string;
  orgName: string;
  orgInitials: string;
  type: "grant" | "tool" | "knowledge" | "partnership";
  title: string;
  body: string;
  date: string;
  openToCollaboration: boolean;
}

export interface Donation {
  id: string;
  orgId: string;
  orgName: string;
  amount: number;
  date: string;
  type: "one-time" | "monthly";
  currency: "GBP";
}

export const ORGANISATIONS: Organisation[] = [
  {
    id: "1",
    name: "Accompong Maroon Foundation",
    shortName: "Accompong",
    mission: "Preserving Maroon heritage, land rights, and cultural practices.",
    location: "St. Elizabeth, Jamaica",
    country: "JM",
    causeCategory: "Cultural Preservation",
    goalAmount: 25000,
    raisedAmount: 16800,
    distributedAmount: 12000,
    donorCount: 143,
    followerCount: 312,
    verified: true,
    initials: "AMF",
    lat: 18.07,
    lng: -77.77,
    stories: [
      { id: "s1a", emoji: "🥁", text: "Day 1 of festival prep", subtext: "Grounds are looking beautiful", gradientFrom: "#2d6a1f", gradientTo: "#1a3a0f" },
      { id: "s1b", emoji: "🌿", text: "Maroon ceremony", subtext: "47 community members gathered", gradientFrom: "#5a2d0f", gradientTo: "#3a1a05" },
      { id: "s1c", emoji: "🏡", text: "Restoration complete", subtext: "First phase done ✓", gradientFrom: "#1a2d6a", gradientTo: "#0f1a3a" },
    ],
    needs: [
      { type: "Money", description: "Festival grounds restoration", urgency: "URGENT", icon: "💰" },
      { type: "Skills", description: "Videographers & photographers", urgency: "OPEN", icon: "🎥" },
      { type: "Time", description: "Festival volunteers, Jan", urgency: "UPCOMING", icon: "⏱" },
      { type: "Presence", description: "Annual Maroon Festival — Jan 6", urgency: "UPCOMING", icon: "🤝" },
    ],
  },
  {
    id: "2",
    name: "Trench Town Heritage Project",
    shortName: "Trench Town Arts",
    mission: "Documenting the musical and cultural roots of Kingston's Trench Town.",
    location: "Kingston, Jamaica",
    country: "JM",
    causeCategory: "Cultural Preservation",
    goalAmount: 18000,
    raisedAmount: 9200,
    distributedAmount: 6500,
    donorCount: 87,
    followerCount: 204,
    verified: true,
    initials: "THP",
    lat: 17.99,
    lng: -76.82,
    stories: [
      { id: "s2a", emoji: "🎙", text: "Recording session live", subtext: "Elder voices, preserved forever", gradientFrom: "#6a1a2d", gradientTo: "#3a0f1a" },
      { id: "s2b", emoji: "🎵", text: "First track mixed", subtext: "Listen when it drops next week", gradientFrom: "#1a1a6a", gradientTo: "#0f0f3a" },
    ],
    needs: [
      { type: "Skills", description: "Audio engineers for recordings", urgency: "URGENT", icon: "🎙" },
      { type: "Money", description: "Recording studio hire", urgency: "OPEN", icon: "💰" },
      { type: "Time", description: "Interview transcribers", urgency: "OPEN", icon: "⏱" },
      { type: "Presence", description: "Community listening events", urgency: "UPCOMING", icon: "🤝" },
    ],
  },
  {
    id: "3",
    name: "Brixton Community Land Trust",
    shortName: "Brixton CLT",
    mission: "Securing affordable community spaces and housing in Brixton.",
    location: "Brixton, London",
    country: "GB",
    causeCategory: "Land & Housing",
    goalAmount: 45000,
    raisedAmount: 31500,
    distributedAmount: 22000,
    donorCount: 267,
    followerCount: 589,
    verified: true,
    initials: "BCL",
    lat: 51.46,
    lng: -0.11,
    stories: [
      { id: "s3a", emoji: "🏠", text: "Keys collected today", subtext: "Acre Lane is officially ours", gradientFrom: "#1a5a6a", gradientTo: "#0f2d3a" },
      { id: "s3b", emoji: "✊", text: "Community meeting packed", subtext: "200 people showed up", gradientFrom: "#4a1a6a", gradientTo: "#2a0f3a" },
    ],
    needs: [
      { type: "Money", description: "Legal fees for property transfer", urgency: "URGENT", icon: "💰" },
      { type: "Skills", description: "Property lawyers, pro bono", urgency: "OPEN", icon: "⚖️" },
      { type: "Presence", description: "Council meeting Feb 20", urgency: "UPCOMING", icon: "🤝" },
      { type: "Time", description: "Community canvassers", urgency: "OPEN", icon: "⏱" },
    ],
  },
  {
    id: "4",
    name: "Caribbean Elders Collective",
    shortName: "Elders Collective",
    mission: "Supporting Windrush-generation elders in East London.",
    location: "Hackney, London",
    country: "GB",
    causeCategory: "Community Wellbeing",
    goalAmount: 12000,
    raisedAmount: 7400,
    distributedAmount: 5800,
    donorCount: 96,
    followerCount: 178,
    verified: true,
    initials: "CEC",
    lat: 51.55,
    lng: -0.06,
    stories: [
      { id: "s4a", emoji: "🍛", text: "Saturday lunch served", subtext: "34 elders, one table", gradientFrom: "#6a3a1a", gradientTo: "#3a1a0f" },
      { id: "s4b", emoji: "❤️", text: "Ms Williams turned 91", subtext: "We sang. She cried. We all did.", gradientFrom: "#6a1a1a", gradientTo: "#3a0f0f" },
    ],
    needs: [
      { type: "Time", description: "Companionship visits, 2hrs/week", urgency: "URGENT", icon: "⏱" },
      { type: "Skills", description: "Counsellors & social workers", urgency: "OPEN", icon: "🩺" },
      { type: "Money", description: "Winter heating vouchers", urgency: "OPEN", icon: "💰" },
      { type: "Presence", description: "Monthly community lunch", urgency: "UPCOMING", icon: "🤝" },
    ],
  },
  {
    id: "5",
    name: "Portland Healing Circle",
    shortName: "Portland Healing",
    mission: "Mental health support for Portland Parish after Hurricane Melissa.",
    location: "Portland, Jamaica",
    country: "JM",
    causeCategory: "Healing & Wellbeing",
    goalAmount: 20000,
    raisedAmount: 5400,
    distributedAmount: 2800,
    donorCount: 52,
    followerCount: 143,
    verified: false,
    initials: "PHC",
    lat: 18.18,
    lng: -76.43,
    stories: [
      { id: "s5a", emoji: "🌊", text: "Circle session in Portland", subtext: "Healing takes time. We're here.", gradientFrom: "#1a3a6a", gradientTo: "#0f1a3a" },
    ],
    needs: [
      { type: "Skills", description: "Trauma counsellors", urgency: "URGENT", icon: "🧠" },
      { type: "Money", description: "Healing circle supplies", urgency: "OPEN", icon: "💰" },
      { type: "Time", description: "Facilitators, weekly sessions", urgency: "OPEN", icon: "⏱" },
      { type: "Presence", description: "Community rebuild day", urgency: "UPCOMING", icon: "🤝" },
    ],
  },
  {
    id: "6",
    name: "Notting Hill Carnival Arts Trust",
    shortName: "Carnival Arts",
    mission: "Sustaining the arts and costume culture of Carnival.",
    location: "Notting Hill, London",
    country: "GB",
    causeCategory: "Arts & Culture",
    goalAmount: 30000,
    raisedAmount: 18900,
    distributedAmount: 14200,
    donorCount: 189,
    followerCount: 441,
    verified: true,
    initials: "NHC",
    lat: 51.51,
    lng: -0.21,
    stories: [
      { id: "s6a", emoji: "🎨", text: "Costume workshop day 3", subtext: "20 young designers in the building", gradientFrom: "#5a1a6a", gradientTo: "#2d0f3a" },
      { id: "s6b", emoji: "🪭", text: "The feathers arrived", subtext: "700 of them. It's giving Caribbean.", gradientFrom: "#6a3a1a", gradientTo: "#3a1a0f" },
    ],
    needs: [
      { type: "Skills", description: "Mas-makers, costume designers", urgency: "OPEN", icon: "🎨" },
      { type: "Money", description: "Materials for 2026 costumes", urgency: "URGENT", icon: "💰" },
      { type: "Time", description: "Workshop assistants", urgency: "OPEN", icon: "⏱" },
      { type: "Presence", description: "Carnival August Bank Holiday", urgency: "UPCOMING", icon: "🤝" },
    ],
  },
];

export const FEED_POSTS: FeedPost[] = [
  {
    id: "fp1",
    orgId: "3",
    orgInitials: "BCL",
    orgName: "Brixton Community Land Trust",
    tag: "After",
    caption: "Acre Lane is ours. 18 months of fighting. The building stands, and now so do we. This is what community power looks like.",
    timeAgo: "2h ago",
    likesCount: 284,
    commentsCount: 41,
    visual: { type: "image", imageKey: "uk" },
  },
  {
    id: "fp2",
    orgId: "4",
    orgInitials: "CEC",
    orgName: "Caribbean Elders Collective",
    tag: "Need",
    caption: "We need 3 companions this Saturday in Hackney. 4 hours. Could change someone's week. Sign up below.",
    timeAgo: "5h ago",
    likesCount: 96,
    commentsCount: 18,
    needType: "volunteer",
    visual: { type: "gradient", emoji: "❤️", gradientFrom: "#6a1a1a", gradientTo: "#2a0808" },
  },
  {
    id: "fp3",
    orgId: "1",
    orgInitials: "AMF",
    orgName: "Accompong Maroon Foundation",
    tag: "During",
    caption: "Festival grounds restoration underway. Phase 1 nearly done. Your donations built this.",
    timeAgo: "1d ago",
    likesCount: 177,
    commentsCount: 29,
    visual: { type: "image", imageKey: "community" },
  },
  {
    id: "fp4",
    orgId: "6",
    orgInitials: "NHC",
    orgName: "Notting Hill Carnival Arts Trust",
    tag: "During",
    caption: "700 feathers. 20 young designers. 1 August Bank Holiday. We are building something extraordinary.",
    timeAgo: "1d ago",
    likesCount: 312,
    commentsCount: 57,
    visual: { type: "gradient", emoji: "🪭", gradientFrom: "#5a1a6a", gradientTo: "#1a0830" },
  },
  {
    id: "fp5",
    orgId: "2",
    orgInitials: "THP",
    orgName: "Trench Town Heritage Project",
    tag: "Need",
    caption: "We're recording oral histories from elders this weekend. Need audio engineers who can give 2 hours. This is history.",
    timeAgo: "6h ago",
    likesCount: 63,
    commentsCount: 14,
    needType: "skills",
    visual: { type: "gradient", emoji: "🎙", gradientFrom: "#6a1a2d", gradientTo: "#200a12" },
  },
  {
    id: "fp6",
    orgId: "5",
    orgInitials: "PHC",
    orgName: "Portland Healing Circle",
    tag: "Before",
    caption: "Starting our first healing circle next week in Portland. 3 parishes hit hardest by the hurricane. We'll be there.",
    timeAgo: "3d ago",
    likesCount: 148,
    commentsCount: 33,
    visual: { type: "gradient", emoji: "🌊", gradientFrom: "#1a3a6a", gradientTo: "#080f2a" },
  },
];

export const ALL_UPDATES: ImpactUpdate[] = [
  {
    id: "u1", orgId: "1", orgInitials: "AMF", orgName: "Accompong Maroon Foundation",
    title: "Festival grounds restoration begins", body: "We've started rebuilding the ceremonial grounds.",
    tag: "During", date: "Mar 2026", timeAgo: "2h ago",
  },
  {
    id: "u3", orgId: "2", orgInitials: "THP", orgName: "Trench Town Heritage Project",
    title: "Need 3 audio engineers", body: "Recording oral histories from Trench Town elders. Can you give 2 hours?",
    tag: "Need", date: "Mar 2026", timeAgo: "5h ago", needType: "volunteer",
  },
  {
    id: "u4", orgId: "3", orgInitials: "BCL", orgName: "Brixton Community Land Trust",
    title: "Acre Lane purchase approved", body: "18 months of campaigning. The building is ours.",
    tag: "After", date: "Feb 2026", timeAgo: "1d ago",
  },
  {
    id: "u6", orgId: "4", orgInitials: "CEC", orgName: "Caribbean Elders Collective",
    title: "Need volunteers this Saturday", body: "3 companions needed for our Hackney session. Can you give 4 hours?",
    tag: "Need", date: "Mar 2026", timeAgo: "6h ago", needType: "volunteer",
  },
  {
    id: "u7", orgId: "5", orgInitials: "PHC", orgName: "Portland Healing Circle",
    title: "First group sessions underway", body: "Weekly healing circles in 3 communities. People are showing up.",
    tag: "During", date: "Mar 2026", timeAgo: "4h ago",
  },
  {
    id: "u8", orgId: "6", orgInitials: "NHC", orgName: "Notting Hill Carnival Arts Trust",
    title: "2026 workshop series begins", body: "20 young people learning mas-making from masters.",
    tag: "During", date: "Mar 2026", timeAgo: "1d ago",
  },
];

export const DEMO_DONATIONS: Donation[] = [
  { id: "d1", orgId: "3", orgName: "Brixton Community Land Trust", amount: 25, date: "Mar 15, 2026", type: "monthly", currency: "GBP" },
  { id: "d2", orgId: "1", orgName: "Accompong Maroon Foundation", amount: 50, date: "Feb 20, 2026", type: "one-time", currency: "GBP" },
  { id: "d3", orgId: "4", orgName: "Caribbean Elders Collective", amount: 25, date: "Feb 15, 2026", type: "monthly", currency: "GBP" },
];

// ─── Get Help Feature ─────────────────────────────────────────────

export interface HelpReview {
  id: string;
  reviewer: string;
  location: string;
  rating: number;
  body: string;
  verified: boolean;
  date: string;
}

export interface HelpProfile {
  orgId: string;
  services: string[];
  responseTime: "24h" | "48h";
  whatsappNumber: string;
  email: string;
  helpCategories: string[];
  rating: number;
  reviewCount: number;
  reviews: HelpReview[];
}

export interface NeedCategory {
  slug: string;
  emoji: string;
  label: string;
}

export const NEED_CATEGORIES: NeedCategory[] = [
  { slug: "housing", emoji: "🏠", label: "Housing & Shelter" },
  { slug: "food", emoji: "🍲", label: "Food & Nutrition" },
  { slug: "mental-health", emoji: "🧠", label: "Mental Health" },
  { slug: "education", emoji: "📚", label: "Education & Youth" },
  { slug: "legal", emoji: "⚖️", label: "Legal Support" },
  { slug: "land", emoji: "🌱", label: "Land & Community" },
  { slug: "family", emoji: "👶", label: "Family Support" },
  { slug: "health", emoji: "💊", label: "Health & Wellbeing" },
];

export const HELP_PROFILES: HelpProfile[] = [
  {
    orgId: "3",
    services: ["Emergency housing advice", "Tenancy rights support", "Legal referrals", "Eviction prevention"],
    responseTime: "24h",
    whatsappNumber: "+447700900001",
    email: "help@brixtonclt.org",
    helpCategories: ["housing", "legal", "land"],
    rating: 4.8,
    reviewCount: 34,
    reviews: [
      {
        id: "r1",
        reviewer: "Marcia",
        location: "Brixton, London",
        rating: 5,
        body: "They helped me stop an illegal eviction. I had nowhere to turn and they responded the same day. Genuinely life-changing support.",
        verified: true,
        date: "Jan 2025",
      },
      {
        id: "r2",
        reviewer: "Anonymous",
        location: "South London",
        rating: 5,
        body: "Professional, caring, and actually got things done. The housing support was real — not just advice but action.",
        verified: true,
        date: "Dec 2024",
      },
      {
        id: "r3",
        reviewer: "Delroy",
        location: "Lambeth",
        rating: 4,
        body: "Good service, took a couple of days to get back to me but they sorted my tenancy issue properly.",
        verified: false,
        date: "Nov 2024",
      },
    ],
  },
  {
    orgId: "1",
    services: ["Land rights advocacy", "Community mediation", "Youth mentorship", "Cultural heritage support"],
    responseTime: "48h",
    whatsappNumber: "+18765550001",
    email: "help@accompong.org",
    helpCategories: ["land", "education", "legal"],
    rating: 4.9,
    reviewCount: 28,
    reviews: [
      {
        id: "r4",
        reviewer: "Devon",
        location: "St. Elizabeth, Jamaica",
        rating: 5,
        body: "Helped our family with a land dispute that had gone on for years. They knew exactly who to contact and how to navigate the system.",
        verified: true,
        date: "Feb 2025",
      },
      {
        id: "r5",
        reviewer: "Kezia",
        location: "Westmoreland, Jamaica",
        rating: 5,
        body: "Incredible knowledge of land rights. They fought for us when we had given up. Can't thank them enough.",
        verified: true,
        date: "Jan 2025",
      },
    ],
  },
  {
    orgId: "2",
    services: ["Youth counselling", "Creative therapy", "After-school programmes", "Trauma support"],
    responseTime: "24h",
    whatsappNumber: "+18765550002",
    email: "help@trenchtownarts.org",
    helpCategories: ["mental-health", "education", "family"],
    rating: 4.7,
    reviewCount: 19,
    reviews: [
      {
        id: "r6",
        reviewer: "Simone",
        location: "Kingston, Jamaica",
        rating: 5,
        body: "My son was struggling badly after losing his dad. The counselling here gave him a safe place. I'm so grateful.",
        verified: true,
        date: "Mar 2025",
      },
    ],
  },
  {
    orgId: "4",
    services: ["Befriending visits", "Wellbeing checks", "Food delivery", "Benefits advice", "Social activities"],
    responseTime: "24h",
    whatsappNumber: "+447700900004",
    email: "help@cecollective.org.uk",
    helpCategories: ["health", "food", "family", "mental-health"],
    rating: 4.9,
    reviewCount: 47,
    reviews: [
      {
        id: "r7",
        reviewer: "Winston",
        location: "Hackney, London",
        rating: 5,
        body: "I was isolated for months. These people visited me twice a week and helped sort my benefits. I can't thank them enough.",
        verified: true,
        date: "Jan 2025",
      },
      {
        id: "r8",
        reviewer: "Anonymous",
        location: "East London",
        rating: 4,
        body: "Very responsive and kind. Food parcels were a lifeline during a tough period.",
        verified: false,
        date: "Nov 2024",
      },
    ],
  },
  {
    orgId: "5",
    services: ["Mental health support", "Crisis counselling", "Peer support groups", "Trauma recovery"],
    responseTime: "48h",
    whatsappNumber: "+18765550005",
    email: "help@portlandhealing.org",
    helpCategories: ["mental-health", "health", "family"],
    rating: 4.6,
    reviewCount: 12,
    reviews: [
      {
        id: "r9",
        reviewer: "Kezia",
        location: "Portland, Jamaica",
        rating: 5,
        body: "The peer support group changed my life. I didn't feel alone anymore. The facilitators are incredible.",
        verified: true,
        date: "Feb 2025",
      },
    ],
  },
];
