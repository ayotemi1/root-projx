import { pgTable, text, timestamp, real } from "drizzle-orm/pg-core";

export const donationsTable = pgTable("donations", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  orgId: text("org_id").notNull(),
  orgName: text("org_name").notNull(),
  amount: real("amount").notNull(),
  date: timestamp("date").defaultNow().notNull(),
  type: text("type").notNull().default("one-time"), // one-time | monthly
  currency: text("currency").notNull().default("GBP"),
});

export type Donation = typeof donationsTable.$inferSelect;
