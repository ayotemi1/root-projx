# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Root ProjX Mobile App (`artifacts/mobile`)

Expo Go app for diaspora donors connecting to grassroots orgs in Jamaica & UK.

**Brand**: Deep red `#CC0000` + gold `#F5B800`. White card theme for donor side; deep red `#B50000` immersive theme for Get Help.

**Tab order**: Feed → Discover → Giving → Get Help → Account

**Key routes:**
- `app/(tabs)/feed.tsx` — Instagram-style social impact feed (home tab)
- `app/(tabs)/index.tsx` — Discover / map tab
- `app/(tabs)/give.tsx` — Giving / donations tab
- `app/(tabs)/help.tsx` — Get Help home (Screen 1: category grid)
- `app/(tabs)/account.tsx` — Account tab
- `app/organisation/[id].tsx` — Donor-facing org profile
- `app/help/[category].tsx` — Get Help results by need category (Screen 2)

**Get Help feature design tokens** (immersive red mode):
- bg: `#B50000`, surface: `#7A0000`, mid: `#9E0000`, gold: `#F5B800`

**Fonts**: `Barlow_900Black`, `Barlow_800ExtraBold` (heavy block style)

**Mock data** in `constants/data.ts`: 6 orgs, FEED_POSTS, HELP_PROFILES (5 orgs with services/ratings/reviews), NEED_CATEGORIES (8 categories)

**Critical**: Never create app.config.ts/js — app.json only. Expo Go only — no extra native modules. Splash in `SplashOverlay.tsx` (1100ms delay on `#CC0000`) — do not touch.

## Root ProjX Web App (`artifacts/web`)

React + Vite companion website at `/web/`. Full app parity with the mobile app.

**Preview path**: `/web/`

**Auth**: Token-based (Bearer token in `Authorization` header). Token stored in `localStorage`. `setAuthTokenGetter` from `@workspace/api-client-react` wires the token into all API calls.

**Pages:**
- `/` — Landing page (unauthenticated): wordmark + Sign In / Create Account
- `/login` — Email-only sign-in (passwordless)
- `/register` — Name (required), Email (required), Phone (optional)
- `/feed` — Impact feed with Before/During/After/Need post cards
- `/discover` — Browse orgs, filter by country (JM/GB) or category
- `/organisations/:id` — Org detail with needs, fund progress, follow/unfollow
- `/giving` — Donor dashboard: stats + donation history + Give Now form
- `/help` — Help category grid
- `/help/:category` — Help org results with WhatsApp, rating, response time
- `/profile` — Edit name/phone, view email, sign out

**API routes** (all under `/api/`):
- `POST /auth/register`, `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`, `PUT /auth/me`
- `GET /organisations`, `GET /organisations/:id`
- `GET /feed`
- `GET /donations`, `POST /donations`
- `GET /follows`, `POST /follows`, `DELETE /follows/:orgId`
- `GET /profile/stats`
- `GET /help/categories`, `GET /help/:category/orgs`

**DB tables**: `users`, `organisations`, `feed_posts`, `donations`, `follows`

**Seed data**: 6 organisations (3 JM + 3 GB), 6 feed posts

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
