import { pgTable, text, timestamp, primaryKey } from "drizzle-orm/pg-core";

export const followsTable = pgTable("follows", {
  userId: text("user_id").notNull(),
  orgId: text("org_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.userId, table.orgId] }),
}));

export type Follow = typeof followsTable.$inferSelect;
