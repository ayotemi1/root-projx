import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { ORGANISATIONS, type Organisation } from "@/constants/data";
import { useColors } from "@/hooks/useColors";

type ViewMode = "list" | "map" | "near";

function CompactCard({ org, isFollowing, onFollow, onDonate }: {
  org: Organisation;
  isFollowing: boolean;
  onFollow: () => void;
  onDonate: () => void;
}) {
  const colors = useColors();
  const progress = Math.min(org.raisedAmount / org.goalAmount, 1);
  const fmt = (n: number) => n >= 1000 ? `£${(n / 1000).toFixed(0)}k` : `£${n}`;

  return (
    <Pressable
      style={({ pressed }) => [styles.compactCard, {
        backgroundColor: colors.card,
        opacity: pressed ? 0.92 : 1,
        borderWidth: 1,
        borderColor: "rgba(245,184,0,0.22)",
      }]}
      onPress={() => router.push(`/organisation/${org.id}`)}
    >
      <View style={[styles.compactHeader, { backgroundColor: "#F8F3E8" }]}>
        <View style={[styles.avatar, { backgroundColor: colors.deepRed }]}>
          <Text style={[styles.avatarText, { color: "#FFFFFF" }]}>{org.initials}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Text style={[styles.orgName, { color: "#1A0800" }]} numberOfLines={1}>{org.shortName}</Text>
            {org.verified && <Ionicons name="checkmark-circle" size={12} color={colors.gold} />}
          </View>
          <Text style={[styles.orgLocation, { color: "#8B6914" }]} numberOfLines={1}>{org.location}</Text>
        </View>
        <View style={[styles.causePill, { backgroundColor: "rgba(245,184,0,0.15)", borderColor: "rgba(245,184,0,0.3)", borderWidth: 1 }]}>
          <Text style={[styles.causeText, { color: "#8B6914" }]} numberOfLines={1}>{org.causeCategory.split(" ")[0]}</Text>
        </View>
      </View>

      <View style={[styles.compactBody, { backgroundColor: colors.card }]}>
        <View style={styles.progressRow}>
          <Text style={[styles.raisedBig, { color: colors.gold }]}>{fmt(org.raisedAmount)}</Text>
          <Text style={[styles.goalSmall, { color: colors.mutedForeground }]}>  of {fmt(org.goalAmount)}</Text>
          <View style={{ flex: 1 }} />
          <Text style={[styles.donorCount, { color: colors.mutedForeground }]}>{org.donorCount} donors</Text>
        </View>
        <View style={[styles.progressTrack, { backgroundColor: "rgba(245,184,0,0.15)" }]}>
          <View style={[styles.progressBar, { backgroundColor: colors.gold, width: `${progress * 100}%` as any }]} />
        </View>
        <View style={styles.cardActions}>
          <Pressable style={[styles.donateBtn, { backgroundColor: colors.deepRed }]} onPress={onDonate}>
            <Text style={[styles.donateBtnText, { color: "#FFFFFF" }]}>Donate</Text>
          </Pressable>
          <Pressable
            style={[styles.followBtn, {
              borderColor: isFollowing ? colors.gold : "rgba(245,184,0,0.30)",
              backgroundColor: isFollowing ? "rgba(245,184,0,0.1)" : "transparent",
            }]}
            onPress={onFollow}
          >
            <Ionicons name={isFollowing ? "heart" : "heart-outline"} size={14} color={isFollowing ? colors.gold : colors.mutedForeground} />
            <Text style={[styles.followBtnText, { color: isFollowing ? colors.gold : colors.mutedForeground }]}>
              {isFollowing ? "Following" : "Follow"}
            </Text>
          </Pressable>
        </View>
      </View>
    </Pressable>
  );
}

const MAP_PINS = [
  { id: "1", label: "Accompong", x: 0.22, y: 0.38 },
  { id: "2", label: "Trench Town", x: 0.45, y: 0.55 },
  { id: "5", label: "Portland", x: 0.71, y: 0.28 },
  { id: "3", label: "Brixton CLT", x: 0.35, y: 0.72 },
  { id: "4", label: "Elders Coll.", x: 0.62, y: 0.65 },
  { id: "6", label: "Carnival Arts", x: 0.18, y: 0.68 },
];

function MapView({ orgs, onSelectOrg, selectedId }: { orgs: Organisation[]; onSelectOrg: (id: string) => void; selectedId: string | null }) {
  const colors = useColors();
  const mapW = 335;
  const mapH = 280;

  return (
    <View style={[styles.mapContainer, { backgroundColor: "#1a3a1a", width: mapW, height: mapH }]}>
      {[0, 1, 2, 3, 4].map(i => (
        <View key={`h${i}`} style={[styles.gridLine, styles.gridH, { top: (mapH / 4) * i, width: mapW, backgroundColor: "rgba(255,255,255,0.06)" }]} />
      ))}
      {[0, 1, 2, 3, 4, 5].map(i => (
        <View key={`v${i}`} style={[styles.gridLine, styles.gridV, { left: (mapW / 5) * i, height: mapH, backgroundColor: "rgba(255,255,255,0.06)" }]} />
      ))}
      {MAP_PINS.filter(p => orgs.find(o => o.id === p.id)).map(pin => {
        const isSelected = pin.id === selectedId;
        return (
          <Pressable
            key={pin.id}
            style={[styles.mapPin, { left: pin.x * mapW - 40, top: pin.y * mapH - 28 }]}
            onPress={() => onSelectOrg(pin.id)}
          >
            <View style={[styles.pinLabel, { backgroundColor: isSelected ? colors.gold : "#FFFFFF", borderColor: isSelected ? colors.gold : "rgba(255,255,255,0.8)" }]}>
              <Text style={[styles.pinText, { color: isSelected ? colors.deepRed : "#1a1a1a" }]}>{pin.label}</Text>
            </View>
            <View style={[styles.pinDot, { backgroundColor: isSelected ? colors.gold : "#FFFFFF" }]} />
          </Pressable>
        );
      })}
      <View style={styles.zoomControls}>
        <View style={[styles.zoomBtn, { backgroundColor: colors.deepRed }]}>
          <Text style={[styles.zoomText, { color: "#FFFFFF" }]}>+</Text>
        </View>
        <View style={[styles.zoomBtn, { backgroundColor: colors.deepRed, marginTop: 2 }]}>
          <Text style={[styles.zoomText, { color: "#FFFFFF" }]}>−</Text>
        </View>
      </View>
    </View>
  );
}

export default function DiscoverScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { toggleFollow, isFollowing } = useApp();
  const [search, setSearch] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [countryFilter, setCountryFilter] = useState<"all" | "JM" | "GB">("all");
  const [selectedMapOrg, setSelectedMapOrg] = useState<string | null>("1");

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const filtered = useMemo(() => ORGANISATIONS.filter(org => {
    const q = search.toLowerCase();
    const matchSearch = !search || org.name.toLowerCase().includes(q) || org.location.toLowerCase().includes(q) || org.causeCategory.toLowerCase().includes(q);
    const matchCountry = countryFilter === "all" || org.country === countryFilter;
    return matchSearch && matchCountry;
  }), [search, countryFilter]);

  const selectedOrg = ORGANISATIONS.find(o => o.id === selectedMapOrg);

  const COUNTRY_FILTERS = [
    { key: "all" as const, flag: "🌍", label: "All" },
    { key: "JM" as const, flag: "🇯🇲", label: "Jamaica" },
    { key: "GB" as const, flag: "🇬🇧", label: "UK" },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Background blobs */}
      <View pointerEvents="none" style={{ position: "absolute", top: -40, right: -60, width: 200, height: 200, borderRadius: 100, backgroundColor: "rgba(245,184,0,0.13)", zIndex: 0 }} />
      <View pointerEvents="none" style={{ position: "absolute", top: 320, left: -80, width: 180, height: 180, borderRadius: 90, backgroundColor: "rgba(204,0,0,0.06)", zIndex: 0 }} />

      {/* Header */}
      <View style={[styles.header, { backgroundColor: "transparent", paddingTop: topPad + 6 }]}>
        <View style={styles.headerRow}>
          <Text style={styles.wordmark}>
            <Text style={{ color: "#CC0000" }}>Root</Text>
            <Text style={{ color: "#F5B800" }}>ProjX</Text>
          </Text>
          <View style={{ backgroundColor: "#CC0000", borderRadius: 22, padding: 9 }}>
            <Ionicons name="notifications-outline" size={22} color="#FFFFFF" />
          </View>
        </View>

        {/* Search */}
        <View style={[styles.searchBar, { backgroundColor: "#FFFFFF", borderColor: "rgba(245,184,0,0.30)", borderWidth: 1 }]}>
          <Ionicons name="search-outline" size={16} color="#CC0000" />
          <TextInput
            style={[styles.searchInput, { color: "#1A0800" }]}
            placeholder="Search organisations..."
            placeholderTextColor="#9CA3AF"
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <Pressable onPress={() => setSearch("")} hitSlop={8}>
              <Ionicons name="close-circle" size={14} color="#9CA3AF" />
            </Pressable>
          )}
        </View>

        {/* Mode toggle */}
        <View style={[styles.modeToggle, { backgroundColor: "#EDE6D6" }]}>
          {([["list", "≡ List"], ["map", "🗺 Map"], ["near", "◎ Near me"]] as [ViewMode, string][]).map(([mode, label]) => (
            <Pressable
              key={mode}
              style={[styles.modeBtn, viewMode === mode && { backgroundColor: "#CC0000" }]}
              onPress={() => setViewMode(mode)}
            >
              <Text style={[styles.modeBtnText, { color: viewMode === mode ? "#FFFFFF" : "#6B7280", fontWeight: viewMode === mode ? "700" : "400" }]}>
                {label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Map view */}
      {viewMode === "map" && (
        <View style={{ flex: 1 }}>
          <View style={{ alignItems: "center", paddingTop: 12 }}>
            <MapView orgs={filtered} onSelectOrg={setSelectedMapOrg} selectedId={selectedMapOrg} />
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.countryRow}>
            {COUNTRY_FILTERS.map(f => (
              <Pressable
                key={f.key}
                style={[styles.countryPill, { backgroundColor: countryFilter === f.key ? colors.gold : "#F0EAD8" }]}
                onPress={() => setCountryFilter(f.key)}
              >
                <Text style={styles.countryFlag}>{f.flag}</Text>
                <Text style={[styles.countryLabel, { color: countryFilter === f.key ? colors.deepRed : colors.mutedForeground, fontWeight: countryFilter === f.key ? "700" : "400" }]}>{f.label}</Text>
              </Pressable>
            ))}
          </ScrollView>
          {selectedOrg && (
            <Pressable
              style={[styles.mapOrgCard, { backgroundColor: "#FFFFFF", borderColor: "rgba(245,184,0,0.25)", borderWidth: 1 }]}
              onPress={() => router.push(`/organisation/${selectedOrg.id}`)}
            >
              <View style={[styles.mapCardAvatar, { backgroundColor: colors.deepRed }]}>
                <Text style={[styles.mapCardInitials, { color: "#FFFFFF" }]}>{selectedOrg.initials}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.mapCardName, { color: "#1A0800" }]}>{selectedOrg.name}</Text>
                <Text style={[styles.mapCardMeta, { color: "#8B6914" }]}>{selectedOrg.location} · {selectedOrg.causeCategory}</Text>
              </View>
              <Pressable
                style={[styles.viewBtn, { backgroundColor: colors.deepRed }]}
                onPress={() => router.push(`/organisation/${selectedOrg.id}`)}
              >
                <Text style={[styles.viewBtnText, { color: "#FFFFFF" }]}>View →</Text>
              </Pressable>
            </Pressable>
          )}
        </View>
      )}

      {/* Near me view */}
      {viewMode === "near" && (
        <View style={styles.nearMe}>
          <Ionicons name="location-outline" size={48} color={colors.gold} />
          <Text style={[styles.nearTitle, { color: "#1A0800" }]}>Find orgs near you</Text>
          <Text style={[styles.nearBody, { color: colors.mutedForeground }]}>Location coming soon</Text>
        </View>
      )}

      {/* List view */}
      {viewMode === "list" && (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.countryRow}>
            {COUNTRY_FILTERS.map(f => (
              <Pressable
                key={f.key}
                style={[styles.countryPill, { backgroundColor: countryFilter === f.key ? colors.gold : "#F0EAD8" }]}
                onPress={() => setCountryFilter(f.key)}
              >
                <Text style={styles.countryFlag}>{f.flag}</Text>
                <Text style={[styles.countryLabel, { color: countryFilter === f.key ? colors.deepRed : colors.mutedForeground, fontWeight: countryFilter === f.key ? "700" : "400" }]}>{f.label}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <FlatList
            data={filtered}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <CompactCard
                org={item}
                isFollowing={isFollowing(item.id)}
                onFollow={() => toggleFollow(item.id)}
                onDonate={() => router.push(`/donate/${item.id}`)}
              />
            )}
            contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 0) + 100 }]}
            showsVerticalScrollIndicator={false}
          />
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, zIndex: 1 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  wordmark: { fontSize: 28, fontFamily: "Barlow_900Black", letterSpacing: -0.3 },
  searchBar: { flexDirection: "row", alignItems: "center", borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, gap: 8, marginBottom: 10 },
  searchInput: { flex: 1, fontSize: 14, padding: 0 },
  modeToggle: { flexDirection: "row", borderRadius: 14, padding: 3 },
  modeBtn: { flex: 1, paddingVertical: 8, borderRadius: 11, alignItems: "center" },
  modeBtnText: { fontSize: 13 },
  countryRow: { paddingHorizontal: 20, paddingVertical: 10, gap: 8, flexDirection: "row" },
  countryPill: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, gap: 5 },
  countryFlag: { fontSize: 15 },
  countryLabel: { fontSize: 13 },
  list: { paddingHorizontal: 20, paddingTop: 4 },
  compactCard: { borderRadius: 16, overflow: "hidden", marginBottom: 14 },
  compactHeader: { flexDirection: "row", alignItems: "center", padding: 12, gap: 10 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  avatarText: { fontSize: 13, fontWeight: "800" },
  orgName: { fontSize: 15, fontFamily: "Barlow_900Black", letterSpacing: 0.3 },
  orgLocation: { fontSize: 11, marginTop: 1 },
  causePill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, maxWidth: 80 },
  causeText: { fontSize: 10, fontWeight: "600" },
  compactBody: { padding: 12, paddingTop: 10 },
  progressRow: { flexDirection: "row", alignItems: "baseline", marginBottom: 6 },
  raisedBig: { fontSize: 22, fontFamily: "Barlow_900Black" },
  goalSmall: { fontSize: 12 },
  donorCount: { fontSize: 11 },
  progressTrack: { height: 4, borderRadius: 2, overflow: "hidden", marginBottom: 10 },
  progressBar: { height: "100%", borderRadius: 2 },
  cardActions: { flexDirection: "row", gap: 8 },
  donateBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: "center" },
  donateBtnText: { fontSize: 15, fontFamily: "Barlow_900Black", letterSpacing: 0.5 },
  followBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: "center", borderWidth: 1.5, flexDirection: "row", justifyContent: "center", gap: 5 },
  followBtnText: { fontSize: 13, fontWeight: "600" },
  mapContainer: { borderRadius: 16, overflow: "hidden", position: "relative" },
  gridLine: { position: "absolute" },
  gridH: { height: 1 },
  gridV: { width: 1 },
  mapPin: { position: "absolute", alignItems: "center" },
  pinLabel: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, borderWidth: 1 },
  pinText: { fontSize: 11, fontWeight: "700" },
  pinDot: { width: 8, height: 8, borderRadius: 4, marginTop: 2 },
  zoomControls: { position: "absolute", top: 10, right: 10 },
  zoomBtn: { width: 28, height: 28, borderRadius: 6, alignItems: "center", justifyContent: "center" },
  zoomText: { fontSize: 18, fontWeight: "300", lineHeight: 26 },
  mapOrgCard: { marginHorizontal: 20, marginTop: 12, borderRadius: 16, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  mapCardAvatar: { width: 44, height: 44, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  mapCardInitials: { fontSize: 13, fontWeight: "800" },
  mapCardName: { fontSize: 14, fontWeight: "700" },
  mapCardMeta: { fontSize: 12, marginTop: 2 },
  viewBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  viewBtnText: { fontSize: 13, fontWeight: "700" },
  nearMe: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  nearTitle: { fontSize: 20, fontWeight: "700" },
  nearBody: { fontSize: 14 },
});
