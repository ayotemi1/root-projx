import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

import { DEMO_DONATIONS, type Donation, type Organisation } from "@/constants/data";

interface AppState {
  following: string[];
  donations: Donation[];
  toggleFollow: (orgId: string) => void;
  addDonation: (donation: Donation) => void;
  isFollowing: (orgId: string) => boolean;
  totalGiven: number;
}

const AppContext = createContext<AppState>({
  following: [],
  donations: [],
  toggleFollow: () => {},
  addDonation: () => {},
  isFollowing: () => false,
  totalGiven: 0,
});

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [following, setFollowing] = useState<string[]>(["3", "1"]);
  const [donations, setDonations] = useState<Donation[]>(DEMO_DONATIONS);

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem("@rootprojx_following");
        if (stored) setFollowing(JSON.parse(stored));
        const storedDonations = await AsyncStorage.getItem("@rootprojx_donations");
        if (storedDonations) setDonations(JSON.parse(storedDonations));
      } catch {}
    })();
  }, []);

  const toggleFollow = async (orgId: string) => {
    const next = following.includes(orgId)
      ? following.filter((id) => id !== orgId)
      : [...following, orgId];
    setFollowing(next);
    try {
      await AsyncStorage.setItem("@rootprojx_following", JSON.stringify(next));
    } catch {}
  };

  const addDonation = async (donation: Donation) => {
    const next = [donation, ...donations];
    setDonations(next);
    if (!following.includes(donation.orgId)) {
      await toggleFollow(donation.orgId);
    }
    try {
      await AsyncStorage.setItem("@rootprojx_donations", JSON.stringify(next));
    } catch {}
  };

  const isFollowing = (orgId: string) => following.includes(orgId);

  const totalGiven = donations.reduce((sum, d) => sum + d.amount, 0);

  return (
    <AppContext.Provider value={{ following, donations, toggleFollow, addDonation, isFollowing, totalGiven }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
